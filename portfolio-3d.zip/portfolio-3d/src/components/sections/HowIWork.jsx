import { MotionSection } from "../../animations/MotionWrappers";
import { fadeUp, staggerContainer } from "../../animations/variants";
import { motion } from "framer-motion";
import { siteContent } from "../../content";

const HowIWork = () => {
  const { howIWork } = siteContent;

  return (
    <MotionSection id="skills" variants={staggerContainer} className="py-24 scroll-mt-24">
      <div className="nb-container">
        <motion.div variants={fadeUp} className="max-w-3xl">
          <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 dark:text-slate-100">
            {howIWork.title}
          </h2>
          <p className="mt-4 text-slate-700 dark:text-slate-400 leading-relaxed">{howIWork.intro}</p>

          <ul className="mt-8 space-y-4">
            {howIWork.points.map((p, i) => (
              <motion.li
                key={p}
                initial={{ opacity: 0, x: -16 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08, type: "spring", stiffness: 200 }}
                className="flex items-start gap-3 text-slate-800 dark:text-slate-200"
              >
                <motion.span
                  className="mt-[7px] h-2.5 w-2.5 rounded-full shrink-0 bg-gradient-to-br from-cyan-300/90 via-indigo-400/90 to-indigo-500/70 ring-4 ring-white/10"
                  whileInView={{ scale: [0, 1.3, 1] }}
                  transition={{ delay: i * 0.08 + 0.2, duration: 0.4 }}
                  viewport={{ once: true }}
                />
                <span className="leading-relaxed font-medium">{p}</span>
              </motion.li>
            ))}
          </ul>
        </motion.div>
      </div>
    </MotionSection>
  );
};

export default HowIWork;
