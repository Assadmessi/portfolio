import { memo } from "react";
import { MotionSection } from "../../animations/MotionWrappers";
import { fadeUp, staggerContainer } from "../../animations/variants";
import { motion } from "framer-motion";
import { siteContent } from "../../content";
import Tilt3DCard from "../three/Tilt3DCard";
import FloatingOrb from "../three/FloatingOrb";

const Services = ({ tick }) => {
  void tick;
  const { services } = siteContent;

  const EMAIL    = services.email;
  const subject  = services.emailSubject;
  const body     = services.emailBodyLines.join("\r\n");
  const mailtoHref = `mailto:${EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

  const serviceCards = services.cards;
  const process      = services.processSteps;

  return (
    <MotionSection id="services" variants={staggerContainer} className="relative py-24 scroll-mt-24 overflow-hidden">
      <FloatingOrb size={420} x="85%" y="20%" color="violet" opacity={0.08} blur={80} delay={0} duration={10} zIndex={0} />
      <FloatingOrb size={300} x="-5%" y="50%" color="sky"    opacity={0.07} blur={70} delay={1} duration={8}  zIndex={0} />

      <div className="nb-container relative z-10">
        <div className="text-center">
          <motion.h2 variants={fadeUp} className="text-3xl sm:text-4xl font-bold text-slate-900 dark:text-slate-100">
            {services.sectionTitle}
          </motion.h2>
          <motion.p variants={fadeUp} className="mt-5 text-slate-700 dark:text-slate-400 leading-relaxed max-w-3xl mx-auto">
            {services.sectionDescription}
          </motion.p>
          <motion.div variants={fadeUp} className="mt-8 flex flex-col items-center gap-3">
            <motion.a href={mailtoHref} className="nb-btn-primary" whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}>
              {services.ctaLabel}
            </motion.a>
            <p className="text-sm text-slate-700 dark:text-slate-400">
              Based in <span className="text-slate-900 dark:text-slate-200 font-medium">{services.basedIn.location}</span>{" "}
              — available for <span className="text-slate-900 dark:text-slate-200 font-medium">{services.basedIn.remote}</span>.
            </p>
            <p className="text-sm text-slate-700 dark:text-slate-400">
              Typical projects start from{" "}
              <span className="text-slate-900 dark:text-slate-200 font-medium">{services.pricing.range}</span>{" "}
              {services.pricing.suffix}
            </p>
          </motion.div>
        </div>

        <motion.div variants={fadeUp} className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
          {serviceCards.map((s) => (
            <Tilt3DCard key={s.title} intensity={8} scale={1.03} glare={true}>
              <div className="nb-card p-6 h-full">
                <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100">{s.title}</h3>
                <ul className="mt-4 space-y-2 text-sm text-slate-700 dark:text-slate-400">
                  {s.points.map((p) => (
                    <li key={p} className="flex gap-2">
                      <span className="mt-1 text-indigo-500/70 dark:text-indigo-300/80">•</span>
                      <span>{p}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </Tilt3DCard>
          ))}
        </motion.div>

        <motion.div variants={fadeUp} className="mt-16">
          <h3 className="text-xl font-semibold text-center text-slate-900 dark:text-slate-100">
            {services.processTitle}
          </h3>
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
            {process.map((step, i) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ x: 4 }}
                className="relative nb-card p-6"
              >
                <span className="absolute left-0 top-6 bottom-6 w-[3px] rounded-full bg-gradient-to-b from-cyan-300/70 via-indigo-400/70 to-transparent" />
                <p className="pl-4 font-medium text-slate-900 dark:text-slate-100">{step.title}</p>
                <p className="pl-4 mt-2 text-sm text-slate-800 dark:text-slate-400">{step.desc}</p>
              </motion.div>
            ))}
          </div>
          <div className="mt-10 text-center text-sm text-slate-700 dark:text-slate-400">
            <span className="text-slate-900 dark:text-slate-200 font-medium">Tip:</span>{" "}
            {services.tipLine.replace(/^Tip:\s*/i, "")}
          </div>
        </motion.div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-px glow-line opacity-30" />
    </MotionSection>
  );
};

export default memo(Services);
