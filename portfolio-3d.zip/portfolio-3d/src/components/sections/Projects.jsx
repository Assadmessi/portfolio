import { memo, useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { MotionSection } from "../../animations/MotionWrappers";
import { fadeUp, staggerContainer } from "../../animations/variants";
import ProjectModal from "../common/ProjectModal";
import { projectsContent } from "../../content";
import { getProjectDesc, getProjectKey, normalizeProjects, sortProjects } from "../../utils/projects";
import Tilt3DCard from "../three/Tilt3DCard";
import FloatingOrb from "../three/FloatingOrb";

// ── Cloudinary helpers (unchanged) ──────────────────────────────────────────
const isCloudinaryUrl = (url) =>
  typeof url === "string" && url.includes("res.cloudinary.com") && url.includes("/upload/");

const cldTransform = (url, transform) => {
  if (!isCloudinaryUrl(url)) return url;
  return url.replace("/upload/", `/upload/${transform}/`);
};

const cldSrcSetFeatured = (url, widths = [480, 768, 1024, 1440, 1920]) => {
  if (!isCloudinaryUrl(url)) return undefined;
  return widths
    .map((w) => {
      const t = w <= 640 ? `f_auto,q_auto,w_${w},c_fit` : `f_auto,q_auto,w_${w},c_fill,g_auto`;
      return `${cldTransform(url, t)} ${w}w`;
    })
    .join(", ");
};

// ── Project utilities (unchanged) ───────────────────────────────────────────
const normalizeProof = (raw) => {
  if (!raw) return [];
  const arr = Array.isArray(raw) ? raw
    : Array.isArray(raw.items) ? raw.items
    : typeof raw === "object"
      ? Object.entries(raw).filter(([k]) => k !== "items")
          .sort(([a], [b]) => { const na = Number(a), nb = Number(b); return !isNaN(na) && !isNaN(nb) ? na - nb : String(a).localeCompare(String(b)); })
          .map(([, v]) => v)
      : [];
  return arr.filter(Boolean).map((it) =>
    typeof it === "string"
      ? { title: it, desc: "", iconKey: "spark", iconUrl: "" }
      : { title: it?.title ?? "", desc: it?.desc ?? "", iconKey: it?.iconKey ?? "spark", iconUrl: it?.iconUrl ?? "" }
  );
};

const normalizeUrl = (url) => {
  if (!url) return "";
  const u = String(url).trim();
  if (!u) return "";
  return /^https?:\/\//i.test(u) ? u : `https://${u}`;
};

const isDirectImageUrl = (url) => {
  if (!url) return false;
  const s = String(url).trim();
  if (/^data:image\//i.test(s)) return true;
  if (/\.(png|jpe?g|webp|gif|avif|svg)(\?.*)?$/i.test(s)) return true;
  try {
    const u = new URL(normalizeUrl(s));
    const host = u.hostname.toLowerCase();
    if (host.includes("res.cloudinary.com")) return true;
    if (host.includes("imagekit.io") || host.includes("ik.imagekit.io")) return true;
  } catch { return false; }
  return false;
};

const getAutoThumbnailCandidates = (liveUrl) => {
  const url = normalizeUrl(liveUrl);
  if (!url) return [];
  return [
    `https://s.wordpress.com/mshots/v1/${encodeURIComponent(url)}?w=1600`,
    `https://image.thum.io/get/width/1200/crop/800/${url}`,
  ];
};

const resolveProjectImageCandidates = (rawImage, fallbackLiveUrl = "") => {
  const img = normalizeUrl(rawImage);
  if (img) return isDirectImageUrl(img) ? [img] : getAutoThumbnailCandidates(img);
  return fallbackLiveUrl ? getAutoThumbnailCandidates(fallbackLiveUrl) : [];
};

const getProjectLinks = (p) => {
  const links = p?.links ?? {};
  return {
    live: normalizeUrl(links.live ?? links.liveUrl ?? links.url ?? p?.live ?? p?.liveUrl),
    repo: normalizeUrl(links.repo ?? links.github ?? links.repoUrl ?? p?.repo ?? p?.repoUrl),
    pdf:  normalizeUrl(links.pdf  ?? links.pdfUrl  ?? p?.pdf  ?? p?.pdfUrl),
  };
};

const shortText = (text = "", max = 120) => {
  if (typeof text !== "string") return "";
  const t = text.trim();
  return t.length > max ? t.slice(0, max).trimEnd() + "…" : t;
};

const LinkChip = ({ href, label, icon }) => {
  if (!href) return null;
  return (
    <a href={href} target="_blank" rel="noreferrer"
      className="inline-flex items-center gap-2 rounded-full border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/5 px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-white hover:shadow-sm transition"
      onClick={(e) => e.stopPropagation()}
    >
      <span className="text-slate-500 dark:text-slate-300">{icon}</span>
      <span>{label}</span>
    </a>
  );
};

// ── Main Projects component ──────────────────────────────────────────────────
const Projects = ({ tick }) => {
  void tick;

  const { projects: rawProjects, sectionTitle } = projectsContent;
  const projects     = useMemo(() => sortProjects(normalizeProjects(rawProjects), "latest"), [rawProjects]);
  const latestProjects = useMemo(() => projects.slice(0, 3), [projects]);
  const items        = useMemo(() => latestProjects.map((p, i) => ({ p, i, key: getProjectKey(p, i) })), [latestProjects]);

  const [featuredKey,   setFeaturedKey]   = useState(() => getProjectKey(latestProjects?.[0], 0));
  const [activeProject, setActiveProject] = useState(null);

  useEffect(() => {
    if (!items.length) return;
    const exists = items.some((x) => x.key === featuredKey);
    if (!exists) setFeaturedKey(items[0].key);
  }, [items, featuredKey]);

  const featuredItem  = useMemo(() => items.find((x) => x.key === featuredKey) ?? items[0], [items, featuredKey]);
  const swapFeatured  = (item) => setFeaturedKey(item.key);
  const featuredLinks = useMemo(() => getProjectLinks(featuredItem?.p), [featuredItem]);
  const featuredImgRaw = featuredItem?.p?.image ?? featuredItem?.p?.imageUrl ?? featuredItem?.p?.cover ?? featuredItem?.p?.thumbnail ?? "";
  const featuredImgCandidates = useMemo(() => resolveProjectImageCandidates(featuredImgRaw, featuredLinks.live), [featuredImgRaw, featuredLinks.live]);
  const [featuredImgIndex, setFeaturedImgIndex] = useState(0);

  useEffect(() => { setFeaturedImgIndex(0); }, [featuredItem?.key, featuredImgRaw, featuredLinks.live]);
  const featuredImg = featuredImgCandidates[featuredImgIndex] ?? "";

  return (
    <>
      <MotionSection id="projects" variants={staggerContainer} className="relative py-20 sm:py-28 scroll-mt-24 overflow-hidden">
        <FloatingOrb size={450} x="60%" y="-10%" color="indigo" opacity={0.08} blur={90} delay={0.5} duration={10} zIndex={0} />
        <FloatingOrb size={350} x="-5%" y="70%" color="cyan"   opacity={0.07} blur={80} delay={1.5} duration={8}  zIndex={0} />

        <div className="nb-container relative z-10">
          {/* Header */}
          <motion.div variants={fadeUp} className="flex items-start justify-between gap-6 flex-wrap">
            <div className="min-w-0">
              <div className="badge-3d w-fit">Selected work</div>
              <h2 className="mt-4 text-3xl sm:text-4xl font-bold text-slate-900 dark:text-slate-100">
                {sectionTitle}
              </h2>
              <p className="mt-3 text-slate-600 dark:text-slate-400 max-w-2xl">
                Product-focused builds with clean UX, motion polish, and production-ready structure.
              </p>
            </div>
          </motion.div>

          <div className="mt-10 sm:mt-12 grid gap-6 sm:gap-10 lg:grid-cols-12 min-w-0 max-w-full">
            {/* Featured — wrapped in Tilt3DCard */}
            <motion.div variants={fadeUp} className="lg:col-span-8 min-w-0 max-w-full">
              {featuredItem ? (
                <Tilt3DCard intensity={6} scale={1.015} glare={true}>
                  <button
                    type="button"
                    onClick={() => setActiveProject(featuredItem.p)}
                    className="group w-full text-left rounded-3xl overflow-hidden border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/5 hover:bg-white transition shadow-sm hover:shadow-2xl"
                  >
                    <div className="relative">
                      {featuredImg ? (
                        <div className="relative w-full aspect-[21/9] sm:aspect-[16/10] bg-slate-100 dark:bg-white/10">
                          <img
                            src={isCloudinaryUrl(featuredImg) ? cldTransform(featuredImg, "f_auto,q_auto,w_1200,c_fill,g_auto") : featuredImg}
                            srcSet={cldSrcSetFeatured(featuredImg)}
                            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 90vw, 66vw"
                            alt={featuredItem.p.title}
                            className="absolute inset-0 w-full h-full object-contain sm:object-cover object-center group-hover:scale-[1.02] transition duration-700"
                            loading="eager"
                            decoding="async"
                            referrerPolicy="no-referrer"
                            onError={() => setFeaturedImgIndex((idx) => {
                              const next = idx + 1;
                              return next < featuredImgCandidates.length ? next : idx;
                            })}
                          />
                          {/* Gradient overlay for depth */}
                          <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition duration-500" />
                        </div>
                      ) : (
                        <div className="aspect-[21/9] sm:aspect-[16/10] w-full bg-slate-100 dark:bg-white/10 relative overflow-hidden">
                          {/* 3D placeholder */}
                          <div className="absolute inset-0 flex items-center justify-center">
                            <motion.div
                              animate={{ rotate: 360 }}
                              transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
                              className="w-16 h-16 border-2 border-indigo-400/30 rounded-full flex items-center justify-center"
                            >
                              <div className="w-8 h-8 border-2 border-cyan-400/40 rounded-full" />
                            </motion.div>
                          </div>
                        </div>
                      )}
                      <div className="absolute top-4 left-4">
                        <span className="badge-3d">Featured</span>
                      </div>
                    </div>

                    <div className="p-5 sm:p-7">
                      <div className="flex items-start justify-between gap-3 sm:gap-4 min-w-0">
                        <div className="min-w-0">
                          <h3 className="text-lg sm:text-xl font-semibold text-slate-900 dark:text-slate-100 truncate">
                            {featuredItem.p?.title}
                          </h3>
                          <p className="mt-2 text-slate-600 dark:text-slate-400 leading-relaxed break-words">
                            {shortText(getProjectDesc(featuredItem.p), 160)}
                          </p>

                          <div key={`story-${featuredKey}`} className="mt-5 grid gap-3 sm:grid-cols-2">
                            {[
                              { label: "Problem (Project story)",   value: featuredItem.p?.problem  },
                              { label: "System (Architecture)",     value: featuredItem.p?.system   },
                              { label: "Solution (What you built)", value: featuredItem.p?.solution },
                              { label: "Impact (Result)",           value: featuredItem.p?.impact   },
                            ].map((it, idx) => (
                              <div key={`${featuredKey}-story-${idx}`} className="min-w-0">
                                <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">{it.label}</div>
                                <div className="mt-2 relative rounded-2xl border border-slate-200/70 dark:border-white/10 bg-white/60 dark:bg-white/5 px-3 sm:px-4 py-3 sm:py-4 overflow-hidden">
                                  <span aria-hidden className="pointer-events-none absolute inset-0 rounded-2xl ring-1 ring-black/5 dark:ring-white/10" />
                                  <span aria-hidden className="pointer-events-none absolute -bottom-px -right-px h-7 w-7 rounded-br-2xl border-b border-r border-slate-200/70 dark:border-white/10" />
                                  <span aria-hidden className="pointer-events-none absolute bottom-2 right-2 h-px w-10 rotate-45 origin-right bg-slate-200/70 dark:bg-white/10" />
                                  <div className="relative text-sm text-slate-700 dark:text-slate-300 leading-relaxed break-words">
                                    {it.value ? it.value : "—"}
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                        <span className="hidden sm:inline shrink-0 text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-200 transition">View →</span>
                      </div>

                      {Array.isArray(featuredItem.p?.tech) && featuredItem.p.tech.length ? (
                        <div className="mt-5 flex flex-wrap gap-2">
                          {featuredItem.p.tech.slice(0, 6).map((t, idx) => (
                            <motion.span key={idx} whileHover={{ y: -2 }}
                              className="text-xs bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-3 py-1 rounded-full cursor-default">
                              {t}
                            </motion.span>
                          ))}
                        </div>
                      ) : null}

                      <div className="mt-5 flex flex-wrap gap-2">
                        <LinkChip href={featuredLinks.live} label="Live URL" icon={<svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2"><path d="M10 13a5 5 0 0 1 0-7l1-1a5 5 0 0 1 7 7l-1 1" /><path d="M14 11a5 5 0 0 1 0 7l-1 1a5 5 0 0 1-7-7l1-1" /></svg>} />
                        <LinkChip href={featuredLinks.repo} label="Repo URL" icon={<svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2"><path d="M16 2H8a2 2 0 0 0-2 2v16l6-3 6 3V4a2 2 0 0 0-2-2z" /></svg>} />
                        <LinkChip href={featuredLinks.pdf}  label="PDF URL"  icon={<svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6" /></svg>} />
                      </div>
                    </div>
                  </button>
                </Tilt3DCard>
              ) : (
                <div className="rounded-3xl border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/5 p-8 sm:p-10 text-slate-600 dark:text-slate-400">
                  No projects yet.
                </div>
              )}
            </motion.div>

            {/* List sidebar */}
            <div className="lg:col-span-4 flex flex-col gap-4 min-w-0 max-w-full">
              <motion.div variants={fadeUp} className="rounded-3xl border border-slate-200/70 dark:border-white/10 bg-white/60 dark:bg-white/5 p-5 sm:p-6">
                <div className="text-sm font-semibold text-slate-900 dark:text-slate-100">Latest projects</div>
                <p className="mt-2 text-sm text-slate-600 dark:text-slate-400 leading-relaxed">Only the 3 most recent projects show here.</p>
                <motion.a href="/projects" whileHover={{ x: 4 }} className="mt-4 inline-flex items-center gap-2 rounded-full border border-slate-200/70 dark:border-white/10 bg-white/80 dark:bg-white/5 px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-white transition">
                  View all projects <span aria-hidden>→</span>
                </motion.a>
              </motion.div>

              {items.length ? (
                <motion.div variants={staggerContainer} initial={false} animate="visible"
                  className="rounded-3xl border border-slate-200/70 dark:border-white/10 overflow-hidden">
                  {items.map((item) => {
                    const isActive = item.key === featuredKey;
                    return (
                      <motion.button
                        key={item.key}
                        variants={fadeUp}
                        initial={false}
                        type="button"
                        whileHover={!isActive ? { x: 4 } : {}}
                        onClick={() => !isActive && swapFeatured(item)}
                        className={`w-full text-left px-4 sm:px-5 py-3.5 sm:py-4 bg-white/70 dark:bg-[#0B0F19]/40 transition flex items-center gap-3 sm:gap-4 ${
                          isActive ? "opacity-80 cursor-default" : "hover:bg-slate-50 dark:hover:bg-white/5 cursor-pointer"
                        }`}
                      >
                        <div className={`text-xs font-semibold w-6 shrink-0 ${isActive ? "gradient-text" : "text-slate-500 dark:text-slate-400"}`}>
                          {String(item.i + 1).padStart(2, "0")}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 min-w-0">
                            <div className="font-semibold text-slate-900 dark:text-slate-100 truncate">{item.p?.title}</div>
                            {isActive ? (
                              <span className="shrink-0 text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-900 text-white dark:bg-white dark:text-slate-900">Featured</span>
                            ) : null}
                          </div>
                          <div className="text-sm text-slate-600 dark:text-slate-400 truncate">{shortText(getProjectDesc(item.p), 90)}</div>
                        </div>
                        <div className="ml-auto text-slate-400 shrink-0">↔</div>
                      </motion.button>
                    );
                  })}
                </motion.div>
              ) : null}
            </div>
          </div>
        </div>
      </MotionSection>

      {activeProject ? <ProjectModal project={activeProject} onClose={() => setActiveProject(null)} /> : null}
    </>
  );
};

export default memo(Projects);
