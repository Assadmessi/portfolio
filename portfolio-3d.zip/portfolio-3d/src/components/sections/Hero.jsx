import { memo } from "react";
import { MotionSection } from "../../animations/MotionWrappers";
import { fadeUp, staggerContainer } from "../../animations/variants";
import { motion } from "framer-motion";
import { siteContent } from "../../content";
import logoMark from "../../assets/images/logo.png";
import Tilt3DCard from "../three/Tilt3DCard";
import FloatingOrb from "../three/FloatingOrb";

const Hero = ({ tick }) => {
  void tick;
  const { hero, links } = siteContent;

  const availabilityShort =
    typeof hero?.availability === "string"
      ? hero.availability.split(".")[0] + (hero.availability.includes(".") ? "." : "")
      : "";

  const RESUME_URL   = links.resumeUrl;
  const GITHUB_URL   = links.githubUrl;
  const LINKEDIN_URL = links.linkedinUrl;

  return (
    <MotionSection
      id="home"
      variants={staggerContainer}
      className="relative min-h-[calc(100vh-4rem)] pt-24 flex items-center scroll-mt-24 overflow-hidden"
    >
      <FloatingOrb size={500} x="-8%"  y="5%"  color="indigo" opacity={0.12} blur={100} delay={0}   duration={9}  zIndex={0} />
      <FloatingOrb size={380} x="75%"  y="60%" color="cyan"   opacity={0.10} blur={90}  delay={2}   duration={11} zIndex={0} />
      <FloatingOrb size={260} x="40%"  y="80%" color="violet" opacity={0.08} blur={70}  delay={1.5} duration={7}  zIndex={0} />

      <div className="nb-container relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-7">
            <motion.div variants={fadeUp}>
              <div className="badge-3d w-fit">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-400" />
                </span>
                {hero.badge}
              </div>
            </motion.div>

            <motion.h1 variants={fadeUp} className="nb-title mt-5">
              {hero.name}
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-cyan-300 to-indigo-300">
                {hero.headlineAccent}
              </span>
            </motion.h1>

            <motion.p variants={fadeUp} className="nb-subtitle max-w-2xl">{hero.intro}</motion.p>
            <motion.p variants={fadeUp} className="mt-3 nb-muted">{availabilityShort}</motion.p>

            <motion.div variants={fadeUp} className="mt-10 flex flex-col sm:flex-row gap-4">
              <motion.a href={hero.buttons.primary.href}   className="nb-btn-primary" whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}>{hero.buttons.primary.label}</motion.a>
              <motion.a href={hero.buttons.secondary.href} className="nb-btn"         whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>{hero.buttons.secondary.label}</motion.a>
              <motion.a href={RESUME_URL} download         className="nb-btn"         whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>{hero.buttons.resume.label}</motion.a>
            </motion.div>

            <motion.div variants={fadeUp} className="mt-8 flex items-center gap-4 text-sm nb-muted">
              <a className="hover:text-white transition" href={GITHUB_URL}   target="_blank" rel="noreferrer">{hero.footerLinks.githubLabel}</a>
              <span className="text-black/30 dark:text-white/20">•</span>
              <a className="hover:text-white transition" href={LINKEDIN_URL} target="_blank" rel="noreferrer">{hero.footerLinks.linkedinLabel}</a>
              <span className="text-black/30 dark:text-white/20">•</span>
              <a className="hover:text-white transition" href={hero.footerLinks.contactHref}>{hero.footerLinks.contactLabel}</a>
            </motion.div>
          </div>

          <motion.div variants={fadeUp} className="lg:col-span-5">
            <Tilt3DCard intensity={14} scale={1.04} glare={true}>
              <div className="nb-card nb-ring p-8 md:p-10">
                <div className="flex items-center gap-5">
                  <motion.div
                    className="w-20 h-20 sm:w-24 sm:h-24 rounded-full p-[2px] bg-gradient-to-br from-cyan-300/60 via-indigo-400/30 to-transparent"
                    animate={{ rotate: [0, 360] }}
                    transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                  >
                    <div className="w-full h-full rounded-full overflow-hidden bg-white/70 dark:bg-white/5 backdrop-blur">
                      <img
                        src={hero.photoUrl || siteContent.photoUrl || logoMark}
                        alt={`${hero.name} profile`}
                        className="w-full h-full object-cover object-center"
                        loading="eager"
                        decoding="async"
                      />
                    </div>
                  </motion.div>
                  <div>
                    <div className="text-sm font-semibold">{hero.name}</div>
                    <div className="text-xs nb-muted">{hero.headlineAccent}</div>
                  </div>
                </div>

                <div className="mt-7 grid grid-cols-3 gap-3">
                  {(hero.profileStats?.length
                    ? hero.profileStats
                    : [{ title: "UI", subtitle: "Systems" }, { title: "Motion", subtitle: "Details" }, { title: "Build", subtitle: "Ship" }]
                  ).slice(0, 3).map((s, idx) => (
                    <motion.div key={idx} whileHover={{ y: -3, scale: 1.05 }} transition={{ type: "spring", stiffness: 300 }}
                      className="rounded-2xl border border-white/10 bg-white/5 p-4 cursor-default">
                      <div className="text-lg font-semibold gradient-text">{s.title}</div>
                      <div className="text-xs nb-muted mt-1">{s.subtitle}</div>
                    </motion.div>
                  ))}
                </div>

                <div className="mt-7 rounded-2xl border border-white/10 bg-white/5 p-4 text-sm nb-muted">
                  Fast iteration, clean components, and scalable content updates.
                </div>

                <div aria-hidden className="pointer-events-none absolute -top-px -right-px w-32 h-32 rounded-tr-3xl"
                  style={{ background: "radial-gradient(circle at top right, rgba(34,211,238,0.12), transparent 70%)" }} />
              </div>
            </Tilt3DCard>
          </motion.div>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-px glow-line opacity-40" />
    </MotionSection>
  );
};

export default memo(Hero);
